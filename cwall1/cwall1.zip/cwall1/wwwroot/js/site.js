﻿// Write your Javascript code.
// $().ready(function(){
//     alert("starting");
// })