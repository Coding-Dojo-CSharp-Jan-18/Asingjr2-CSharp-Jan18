namespace cwall1.Models
{
    public class WallViewModel
    {
        public User user {get;set;}
        public Comment comment {get; set;}
        public Message message {get; set;}

    }
}